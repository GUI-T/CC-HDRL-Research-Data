CC-HDRL v2 test instances

This package contains 500 derived CC-HDRL test instances. It includes 50 instances for each of the 10 scenarios formed by N in {100, 150, 200, 300, 500} and U in {4, 6}. The data are from scheme_1_overlap frontend cache version 2.0.2 and retain task positions, cluster assignments, collection points, coverage checks, and sample identifiers.

No training data, model checkpoints, logs, or generated reports are included. See manifest.json for the scenario breakdown.
